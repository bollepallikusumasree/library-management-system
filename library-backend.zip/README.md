# Library Management Backend

## Quick start

1. Copy `.env.example` to `.env` and fill secrets (ACCESS_TOKEN_SECRET, REFRESH_TOKEN_SECRET).
2. Ensure MongoDB is running locally or use a Mongo URI and set `MONGO_URI`.
3. Install:
   ```
   npm install
   ```
4. Seed sample data (creates 5 users and 5 books):
   ```
   npm run seed
   ```
5. Run server:
   ```
   npm run dev
   ```
6. Use Postman:
   - Register: POST /api/auth/register
   - Login: POST /api/auth/login -> returns accessToken & refreshToken
   - Use `Authorization: Bearer <accessToken>` for protected routes
   - Get books: GET /api/books
   - Create book (admin): POST /api/books with admin user token
   - Borrow: POST /api/borrow { username, bookid }
   - Return: POST /api/return { username, bookid }

Default seeded admin credentials: `username: admin`, `password: password123`

