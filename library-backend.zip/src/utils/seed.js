require('dotenv').config();
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const User = require('../models/User');
const Book = require('../models/Book');

async function seed() {
  await mongoose.connect(process.env.MONGO_URI);
  await User.deleteMany({});
  await Book.deleteMany({});

  const pwd = await bcrypt.hash('password123', 10);
  const users = [
    { name:'Admin', username:'admin', password: pwd, email:'admin@lib.com', mobile: 9000000001, admin:true },
    { name:'Alice', username:'alice', password: pwd, email:'alice@lib.com', mobile: 9000000002 },
    { name:'Bob', username:'bob', password: pwd, email:'bob@lib.com', mobile: 9000000003 },
    { name:'Carol', username:'carol', password: pwd, email:'carol@lib.com', mobile: 9000000004 },
    { name:'Dave', username:'dave', password: pwd, email:'dave@lib.com', mobile: 9000000005 }
  ];
  await User.insertMany(users);

  const books = [
    { name:'Clean Code', author:'Robert C. Martin', genre:'Programming', type:'Paperback' },
    { name:'Introduction to Algorithms', author:'CLRS', genre:'Algorithms', type:'Hardcover' },
    { name:'You Don\'t Know JS', author:'Kyle Simpson', genre:'Programming', type:'Paperback' },
    { name:'The Pragmatic Programmer', author:'Andrew Hunt', genre:'Software', type:'Paperback' },
    { name:'Design Patterns', author:'Erich Gamma', genre:'Software', type:'Hardcover' }
  ];
  await Book.insertMany(books);

  console.log('Seeded DB with 5 users and 5 books');
  process.exit();
}

seed().catch(err => { console.error(err); process.exit(1); });
