const express = require('express');
const Book = require('../models/Book');
const { authenticateToken, requireAdmin } = require('../middlewares/auth');
const router = express.Router();

// List all books
router.get('/', async (req, res) => {
  const books = await Book.find();
  res.json(books);
});

// Get single book
router.get('/:id', async (req, res) => {
  const book = await Book.findById(req.params.id);
  if (!book) return res.status(404).json({ message: 'Not found' });
  res.json(book);
});

// Create book (admin)
router.post('/', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const b = new Book(req.body);
    await b.save();
    res.json(b);
  } catch (err) { res.status(400).json({ message: err.message }); }
});

// Update book (admin)
router.put('/:id', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const b = await Book.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(b);
  } catch (err) { res.status(400).json({ message: err.message }); }
});

// Delete book (admin)
router.delete('/:id', authenticateToken, requireAdmin, async (req, res) => {
  try {
    await Book.findByIdAndDelete(req.params.id);
    res.json({ message: 'deleted' });
  } catch (err) { res.status(400).json({ message: err.message }); }
});

module.exports = router;
