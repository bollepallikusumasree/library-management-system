const express = require('express');
const Borrow = require('../models/Borrow');
const Return = require('../models/Return');
const Book = require('../models/Book');
const { authenticateToken } = require('../middlewares/auth');
const router = express.Router();

// return a book
router.post('/', authenticateToken, async (req, res) => {
  try {
    const { username, bookid } = req.body;
    if (!username || !bookid) return res.status(400).json({ message: 'username & bookid required' });
    const borrow = await Borrow.findOne({ username, bookid });
    if (!borrow) return res.status(404).json({ message: 'Borrow record not found' });
    const now = new Date();
    const duedate = borrow.duedate || new Date();
    const lateMs = now - duedate;
    const lateDays = lateMs > 0 ? Math.ceil(lateMs / (24*60*60*1000)) : 0;
    const finePerDay = 10;
    const fine = lateDays * finePerDay;
    const ret = new Return({ username, bookid, duedate, fine });
    await ret.save();
    await Book.findByIdAndUpdate(bookid, { available: true });
    await Borrow.deleteOne({ _id: borrow._id });
    res.json({ returned: ret, fine });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
