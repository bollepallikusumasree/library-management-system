const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');

const router = express.Router();

router.post('/register', async (req, res) => {
  try {
    const { name, username, password, email, mobile, admin } = req.body;
    if (!username || !password) return res.status(400).json({ message: 'username & password required' });
    const existing = await User.findOne({ username });
    if (existing) return res.status(400).json({ message: 'username taken' });
    const hashed = await bcrypt.hash(password, 10);
    const user = new User({ name, username, password: hashed, email, mobile, admin: !!admin });
    await user.save();
    res.json({ message: 'user registered' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

router.post('/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password) return res.status(400).json({ message: 'username & password required' });
    const user = await User.findOne({ username });
    if (!user) return res.status(400).json({ message: 'invalid creds' });
    const ok = await bcrypt.compare(password, user.password);
    if (!ok) return res.status(400).json({ message: 'invalid creds' });
    const payload = { id: user._id, username: user.username, admin: user.admin };
    const accessToken = jwt.sign(payload, process.env.ACCESS_TOKEN_SECRET, { expiresIn: process.env.ACCESS_TOKEN_EXPIRES_IN || '15m' });
    const refreshToken = jwt.sign({ id: user._id }, process.env.REFRESH_TOKEN_SECRET, { expiresIn: process.env.REFRESH_TOKEN_EXPIRES_IN || '7d' });
    res.json({ accessToken, refreshToken });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

router.post('/refresh', async (req, res) => {
  try {
    const { refreshToken } = req.body;
    if (!refreshToken) return res.status(400).json({ message: 'refreshToken required' });
    jwt.verify(refreshToken, process.env.REFRESH_TOKEN_SECRET, async (err, data) => {
      if (err) return res.status(403).json({ message: 'Invalid refresh token' });
      const user = await User.findById(data.id);
      if (!user) return res.status(404).json({ message: 'User not found' });
      const payload = { id: user._id, username: user.username, admin: user.admin };
      const accessToken = jwt.sign(payload, process.env.ACCESS_TOKEN_SECRET, { expiresIn: process.env.ACCESS_TOKEN_EXPIRES_IN || '15m' });
      const newRefresh = jwt.sign({ id: user._id }, process.env.REFRESH_TOKEN_SECRET, { expiresIn: process.env.REFRESH_TOKEN_EXPIRES_IN || '7d' });
      res.json({ accessToken, refreshToken: newRefresh });
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
