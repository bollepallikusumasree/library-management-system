const express = require('express');
const User = require('../models/User');
const { authenticateToken, requireAdmin } = require('../middlewares/auth');
const router = express.Router();

// list users (admin)
router.get('/', authenticateToken, requireAdmin, async (req, res) => {
  const users = await User.find().select('-password');
  res.json(users);
});

module.exports = router;
