const express = require('express');
const Borrow = require('../models/Borrow');
const Book = require('../models/Book');
const { authenticateToken } = require('../middlewares/auth');
const router = express.Router();

// borrow a book
router.post('/', authenticateToken, async (req, res) => {
  try {
    const { username, bookid } = req.body;
    if (!username || !bookid) return res.status(400).json({ message: 'username & bookid required' });
    const book = await Book.findById(bookid);
    if (!book) return res.status(404).json({ message: 'Book not found' });
    if (!book.available) return res.status(400).json({ message: 'Book not available' });
    const borrow = new Borrow({ username, bookid });
    await borrow.save();
    book.available = false;
    await book.save();
    res.json(borrow);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
